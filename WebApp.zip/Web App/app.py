import streamlit as st
import matplotlib.pyplot as plt
from qiskit import *
from src.draw_circuit import draw_qc

from PIL import Image

st.set_page_config(page_title="Quantum Error Correction", layout="wide")

left, right = st.columns([4,5])

header = '<p style="font-family:sans-serif; font-size: 40px;"><span style="color:Orange;">Quantum Error Correction:</span> <span style="color:Skyblue;">Repetition Code</span></p>'

right.markdown(header, unsafe_allow_html=True)

## Tabs

tab1, tab2 = st.tabs(["About", "Application"])

with tab1:

    st.write("Home: Quantum Concept description and visualization will appear here.")


with tab2:

    col1, br0, col2 = st.columns([2,0.2, 8])

    br0.markdown("|  \n"*26)
    
    parameter_header = '<p style="font-family:sans-serif; font-size: 22px;"><span style="color:Skyblue;">Input Parameters</span></p>'

    col1.markdown("  \n"*3)
    col1.markdown(parameter_header, unsafe_allow_html=True)
    col1.markdown("---")
    d = col1.select_slider("Select the number of code qubits (repetitions)",options=[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    col1.write("  \n")
    theme = col1.checkbox("Switch to Dark Theme")
    col1.write("   \n")
    if theme:
        c_style = {'backgroundcolor': '#0e1117', 'linecolor': '#FFFFFF', 'textcolor': '#FFFFFF', 'barrierfacecolor': '#121C2F'}
    else:
        c_style = None

    col1.button("Get Results")

    qc = draw_qc(d)

    #c_style = {'backgroundcolor': '#0e1117', 'linecolor': '#FFFFFF', 'textcolor': '#FFFFFF', 'barrierfacecolor': '#121C2F'}
    #c_style = None

    if d == 3:
        qc.draw(output='mpl', filename="data/circuit.jpg", initial_state=True, style=c_style)
    elif d > 3 and d<7:
        qc.draw(output='mpl', filename="data/circuit.jpg", initial_state=True, fold=0, style=c_style)
    elif d >=7:
        qc.draw(output='mpl', filename="data/circuit.jpg", scale=0.4, fold=0, initial_state=True, style=c_style)

    circuit_img = Image.open("data/circuit.jpg")

    circuit, results = col2.tabs(["Quantum Circuit", "Measurements"])

    with circuit:
        st.image(circuit_img)



